import postsAPI from "./posts.api";

const api = {
  posts: postsAPI,
};
export default api;
