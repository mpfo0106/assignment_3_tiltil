import TILForm from "./_components/TILForm";

function TILWritePage() {
  return (
    <div>
      <TILForm />
    </div>
  );
}

export default TILWritePage;
