import React from "react";

function PostsListItem() {
  return <div>PostsListItem</div>;
}

export default PostsListItem;
