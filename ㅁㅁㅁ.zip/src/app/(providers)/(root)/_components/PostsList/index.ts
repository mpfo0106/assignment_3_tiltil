export { default } from "./PostsList";
